function [v_tm_t, a_tm_t ] = fcn(step, v_e, p_e, v_tm, p_off, Gp, Gv, r_v_tm_t, del_t_tgt, v_tm_init, a_tm_init, th_max_p, th_min_p)

a_min = 0.001;

if ~step
    v_tm_t = v_tm_init;
    a_tm_t = a_tm_init;
    return;
end

del_v_tgt = Gp*(p_off-p_e)+Gv*v_e;
a_tgt = abs(del_v_tgt/del_t_tgt);

v_tm_t = v_tm + del_v_tgt;

v_tm_t = min(v_tm_t, r_v_tm_t(2));
v_tm_t = max(v_tm_t, r_v_tm_t(1));
a_tm_t = max(a_tgt, a_min);



end

