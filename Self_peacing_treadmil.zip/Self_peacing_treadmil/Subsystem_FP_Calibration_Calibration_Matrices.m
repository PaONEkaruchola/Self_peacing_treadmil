function y = fcn(u)
%#codegen
cal = eye(12);

cal(1,1) = 800;
cal(2,2) = 800;
cal(3,3) = 1500;
cal(4,4) = 375;
cal(5,5) = 1200;
cal(6,6) = 600;

cal(7,7) = 800;
cal(8,8) = 800;
cal(9,9) = 1500;
cal(10,10) = 375;
cal(11,11) = 1200;
cal(12,12) = 600;

y = cal*u;