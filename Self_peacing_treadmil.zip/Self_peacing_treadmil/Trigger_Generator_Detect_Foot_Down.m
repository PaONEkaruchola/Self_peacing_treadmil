function [LDown, RDown] = fcn(forceplates,threshold)
%#codegen
L_Fx = forceplates(1);
L_Fy = forceplates(2);
L_Fz = forceplates(3);
L_Tx = forceplates(4);
L_Ty = forceplates(5);
L_Tz = forceplates(6);

R_Fx = forceplates(7);
R_Fy = forceplates(8);
R_Fz = forceplates(9);
R_Tx = forceplates(10);
R_Ty = forceplates(11);
R_Tz = forceplates(12);

LDown = L_Fz > threshold;
RDown = R_Fz > threshold;