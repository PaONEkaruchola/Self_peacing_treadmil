function out = fcn(spdLeft,spdRight,ready)
%#codegen

speeda = [0 0 0 0];
accela = [0 0 0 0];

if(ready)
    accel = 30;
else
    accel = 0.3;
end
incline = 0;

speed = spdRight;
speed2 = spdLeft;

speeda(length(speed)+1:4) = 0;
speeda(1) = speed;
speeda(2) = speed2;
accela(length(accel)+1:4) = 1;
accela(1) = accel;
accela(2) = accel;

speeda = speeda(1:4);
accela = accela(1:4);
accela = abs(accela);

accela(accela > 32.767) = 32.767;
speeda(speeda > 32.767) = 32.767;
speeda(speeda < -32.768) = -32.768;
incline(incline > 45) = 45;

packet = zeros(64, 1, 'uint16');
speedi = int16(round(1000*speeda)); % mm/s
accelu = uint16(round(1000*accela)); % mm/s^2
incline = uint16(round(100*incline)); % 0.01deg
speedu = typecast(speedi, 'uint16');
% packet(2+[0:3]*2) = bitshift(speedu, -8)';
packet(2) = bitshift(speedu(1),-8);
packet(4) = bitshift(speedu(2),-8);
packet(6) = bitshift(speedu(3),-8);
packet(8) = bitshift(speedu(4),-8);
% packet(3+[0:3]*2) = bitand(speedu, 255)';
packet(3) = bitand(speedu(1), 255);
packet(5) = bitand(speedu(2), 255);
packet(7) = bitand(speedu(3), 255);
packet(9) = bitand(speedu(4), 255);
% packet(2+8+[0:3]*2) = bitshift(accelu, -8)';
packet(10) = bitshift(accelu(1), -8);
packet(12) = bitshift(accelu(2), -8);
packet(14) = bitshift(accelu(3), -8);
packet(16) = bitshift(accelu(4), -8);
% packet(3+8+[0:3]*2) = bitand(accelu, 255)';
packet(11) = bitand(accelu(1), 255);
packet(13) = bitand(accelu(2), 255);
packet(15) = bitand(accelu(3), 255);
packet(17) = bitand(accelu(4), 255);
% packet(2+16) = bitshift(incline, -8)';
packet(18) = bitshift(incline, -8);
% packet(3+16) = bitand(incline, 255)';
packet(19) = bitand(incline, 255);

pkt = uint8(packet);
pkt(20:37) = bitxor(pkt(2:19), uint8(255))';

out = pkt;
