function [y,buffer] = fcn(signal, order, bufin)

buffer = [bufin(2:end,:);signal'];

y = mean(buffer(length(buffer)-order+1:end,:))';