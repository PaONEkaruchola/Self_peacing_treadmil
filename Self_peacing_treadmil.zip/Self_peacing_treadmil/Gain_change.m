function [Gp,Gv] = fcn(speed)

    Gp = (-0.25*0.25/0.6)*(speed-0.4) - 0.25*1.25;
    Gv = (-0.15*0.25/0.6)*(speed-0.4) - 0.15*1.25;
end
