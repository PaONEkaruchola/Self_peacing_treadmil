function Theta = TLA_convert(lefthip,leftank,rightank,righthip)

% if rightank(3)

rhiploc = [righthip(2), righthip(3),0];
rankloc = [rightank(2),rightank(3),0];
rvertical = [righthip(2),rightank(3),0] - rhiploc;
rleg = rankloc - rhiploc;
crossR = cross(rvertical, rleg);
ThetaR = atan2d(crossR(end), dot(rvertical, rleg));%'+ 360*(norm(cross(rvertical, rleg))<0);


lhiploc = [lefthip(2), lefthip(3),0];
lankloc = [leftank(2),leftank(3),0];
lvertical = [lefthip(2),leftank(3),0] - lhiploc;
lleg = lankloc - lhiploc;
crossL = cross(lvertical, lleg);
ThetaL = atan2d(crossL(end), dot(lvertical, lleg))';%+ 360*(norm(cross(rvertical, rleg))<0);


Theta = [ThetaR',ThetaL'];

