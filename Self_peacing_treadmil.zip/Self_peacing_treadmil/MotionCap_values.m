function [a_mocap, v_mocap, p_mocap, step, v_filt] = fcn(mocap_data, GS_Left, GS_right, time)

    persistent p_prevs v_prev Ts b a zf_v zf_a
    persistent p_prev t_prev 
    persistent GS_temp_L GS_temp_R step_count
    persistent a_out v_out p_out t_step_out

    if isempty(Ts)
        FS = 1000.0;
        Ts = 1/FS;
        
        FC = 4.0; 
        FO = 4;
        Wn = FC / (FS / 2);
        [b, a] = butter(FO, Wn, 'low');
        
 
        zi = zeros(FO, 1); 
        

        zf_v = zi;
        zf_a = zi;
        
        p_prevs = mocap_data+0.1589;
        v_prev = 0.0;
        
        t_prev = 0.0;
        p_prev = mocap_data+0.1589; 
        step_count = 0;
        GS_temp_L = 0;
        GS_temp_R = 0;
        
        a_out = 0.0;
        v_out = 0.0;
        p_out = 0.0;
        t_step_out = 0.0; 
    end
    
    v_raw = (mocap_data+0.1589 - p_prevs) / Ts;
    
    [v_filt, zf_v] = filter(b, a, v_raw, zf_v);
    
    a_raw = (v_filt - v_prev) / Ts;
    
    [a_filt, zf_a] = filter(b, a, a_raw, zf_a);
    
    a_out = a_filt;
    
    p_prevs = mocap_data+0.1589; 
    v_prev = v_filt; 
    
    GS_right = double(GS_right);
    GS_Left = double(GS_Left);
    
    a_mocap = a_out;
    v_mocap = v_out;
    p_mocap = p_out;
    step = 0; 
    
    is_right_step = (GS_temp_R == 0 && GS_right == 1);
    is_left_step = (GS_temp_L == 0 && GS_Left == 1);
    
    GS_temp_L = GS_Left;
    GS_temp_R = GS_right;
    
    if is_right_step || is_left_step
        step_count = step_count + 1;
        step = 1; 
        t_step = time; 
        
        if step_count > 2
            delta_d = mocap_data+0.1589 - p_prev;
            delt_t = time - t_prev;
            
            if delt_t > 1e-6 
                v_mocap = delta_d / delt_t;
            else
                v_mocap = v_out; 
            end
            
            p_mocap = mocap_data+0.1589;
        end
        
        p_prev = mocap_data+0.1589; 
        t_prev = time;     
        
        v_out = v_mocap;
        p_out = p_mocap;
        t_step_out = t_step;
    end
end