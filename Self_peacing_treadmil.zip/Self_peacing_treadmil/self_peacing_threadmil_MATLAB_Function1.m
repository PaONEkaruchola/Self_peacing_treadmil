function [leftank,lefthip,rightank,righthip, center_x, center_y] = marker_fileter(u)
persistent lefthip_save leftank_save righthip_save rightank_save

if isempty(leftank_save)
    lefthip_save = [0 0 0];
    leftank_save = [0 0 0];
    righthip_save = [0 0 0];
    rightank_save = [0 0 0];
end



chan = [0 0 0];
lefthip = [0 0 0];
leftank = [0 0 0];
rightank = [0 0 0];
righthip = [0 0 0];
center = [0 0 0];

channel0 = [u(1),u(2),u(3)];
channel1 = [u(4),u(5),u(6)];
channel2 = [u(7),u(8),u(9)];
channel3 = [u(10),u(11),u(12)];
channel4 = [u(13),u(14),u(15)];
channel5 = [u(16),u(17),u(18)];
channel6 = [u(19),u(20),u(21)];
channel7 = [u(22),u(23),u(24)];

for i = 1:8
    switch i
        case 1
            chan = channel0;
        case 2
            chan = channel1;
        case 3
            chan = channel2;
        case 4
            chan = channel3;
        case 5
            chan = channel4;
        case 6
            chan = channel5;
        case 7
            chan = channel6;
        case 8
            chan = channel7;
    end
    if chan(3) < 0.06
        ignore = chan;
    elseif chan(3) > 1.3
        ignore = chan;
    elseif chan(1) < 0 && chan(3) > 0.45
        lefthip = chan;
    elseif chan(1) < 0 && chan(3) < 0.45 
        leftank = chan;
    elseif chan(1) > 0 && chan(3) < 0.45
        rightank = chan;
    elseif chan(1) > 0 && chan(3) > 0.45
        righthip = chan;
    else
        disp('Logic not met')
    end

end


if norm(lefthip -[0 0 0]) < 1e-3
    lefthip = lefthip_save;
else
    lefthip_save = lefthip;
end
if norm(leftank -[0 0 0]) < 1e-3
    leftank = leftank_save;
else
    leftank_save = leftank;
end

if norm(righthip -[0 0 0]) < 1e-3
    righthip = righthip_save;
else
    righthip_save = righthip;
end
if norm(rightank -[0 0 0]) < 1e-3
    rightank = rightank_save;
else
    rightank_save = rightank;
end
% output = [lefthip,leftank,rightank,righthip]';

center = [(lefthip(1)+righthip(1))/2 (lefthip(2)+righthip(2))/2];

center_x = center(1);
center_y = center(2);

if lefthip(1) == 0 || leftank(1) == 0 || rightank(1) == 0 || righthip(1) == 0
    disp('Zeros Returned')
end
    
end
