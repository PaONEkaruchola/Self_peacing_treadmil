function [a_mes, v_mes, p_mes, p_e, v_e, step, p_kf, v_kf] = fcn(v_thm, mass, GS_Left, GS_right, time, Fy_Left, Fz_Left, Tx_Left, Fy_Right, Fz_Right, Tx_Right)
 
     
    persistent GS_temp_L GS_temp_R x P time_prev x_mean_step n_ts
    persistent p_heel_strike_1 t_heel_strike_1  % Position and time of the MOST RECENT step
    persistent p_heel_strike_0 t_heel_strike_0  % Position and time of the PREVIOUS step
    persistent step_count v_mes_out p_mes_out v_mes_out2

    
     
    if isempty(step_count) 
        pause(30);
        step_count = 0;
        time_prev = time;
        x_mean_step = [0.0; 0.0];  
        n_ts = 0;  
        GS_temp_L =0;
        GS_temp_R=0;
        v_mes_out2 = NaN;
        p_mes_out = NaN;
        
        %state
        x = [0.0; 0.0]; 
        P = [0.0013 -0.0002; -0.0002 0.0131];
        
        p_heel_strike_1 = 0; t_heel_strike_1 = 0;
        p_heel_strike_0 = 0; t_heel_strike_0 = -0.5; %start with reasonable step time
    end
    GS_Left=double(GS_Left);
    GS_right=double(GS_right);
    
  
    % --- Constants and Time Step ---
    h = 0.0095;
    del_t = time - time_prev;
    if del_t <= 0, del_t = 0.001; end

    % --- Step 0: Input Calculation ---
    a_mes = ((Fy_Left + Fy_Right) / mass); % NOTE: Be sure this doesn't have a DC offset.
    
    % --- Step 1: Kalman Prediction (runs every time) ---
    A = [1 del_t; 0 1];
    B = [del_t^2/2; del_t];
    sigma_a = 1.3647; % Process noise
    Q = B*B'*sigma_a^2;
    
    x = A*x + B*a_mes;
    P = A*P*A' + Q;
    p_kf = x(1);
    v_kf = x(2);
    
    % Update the running average of the state for the next potential update
    x_mean_step = (x_mean_step * n_ts + x) / (n_ts + 1);
    n_ts = n_ts + 1;
    
    % --- Step 2: Check for a New Step Event ---
    step = 0;
    p_mes = p_mes_out;
    v_mes = v_mes_out2;

     

    is_right_step = (GS_temp_R == 0 && double(GS_right) == 1);
    is_left_step = (GS_temp_L == 0 && double(GS_Left) == 1);
    
    if is_right_step || is_left_step
        step = 1;
        step_count = step_count + 1;
        
        % A new step occurred, so the "most recent" step becomes the "previous" one.
        p_heel_strike_0 = p_heel_strike_1;
        t_heel_strike_0 = t_heel_strike_1;

        % Calculate and store the new "most recent" step data
        t_heel_strike_1 = time;
        if is_right_step && abs(Fz_Right) > 1
            p_heel_strike_1 = 1.73 + 0.1695+0.1446-0.1110- ((-h * Fy_Right + Tx_Right) / Fz_Right);
        elseif is_left_step && abs(Fz_Left) > 1
            p_heel_strike_1 = 1.73 + 0.1695+0.1446-0.1110- ((-h * Fy_Left + Tx_Left) / Fz_Left);
        end
        
        % --- Step 3: Kalman Update (only on a new step after the first one) ---
        if step_count > 1
            % Calculate step properties from the UNMODIFIED heel-strike data
            len_step = p_heel_strike_1 - p_heel_strike_0;
            deltT_step = t_heel_strike_1 - t_heel_strike_0;
            
            if deltT_step > 1e-6
                % To calculate COM position, we need the *current* positions of the feet.
                % The previous foot has moved back with the treadmill.
                p0_current_pos = p_heel_strike_0 ; %- v_thm * deltT_step
                p1_current_pos = p_heel_strike_1; % This foot just landed.
                
                % Measurement calculation
                p_mes_out = (p1_current_pos + p0_current_pos) / 2;
                v_mes_out2 = (len_step / deltT_step);
                v_mes_out = (len_step / deltT_step) - v_thm;
                y_mes = [p_mes_out; v_mes_out];

                % Measurement noise
                sigma_v = 0.11464; % Consider increasing these for more smoothing
                sigma_p = 0.035583;
                R = [sigma_p^2, 0; 0, sigma_v^2]; 
                
                % Kalman update equations
                y_est = x_mean_step;
                K = P / (P + R);
                x = x + K * (y_mes - y_est);
                P = (eye(2) - K) * P;
                
                % Reset the running average after the update
                n_ts = 0;
                x_mean_step = [0.0; 0.0];
            end
        end
    end
    
    % --- Step 4: Final Output Assignment ---
    p_e = x(1);
    v_e = x(2);
 
    % Update persistent variables for the next cycle
    GS_temp_L = GS_Left;
    GS_temp_R = GS_right;
    time_prev = time;

    
    
end