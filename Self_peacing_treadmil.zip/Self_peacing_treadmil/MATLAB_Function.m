function v_tm = fcn(t)
t_start = 30;
t_end = 350;
v_start = 0.8;
v_end =1.5;
if t<t_start
    v_tm=0;
elseif t== t_start
    v_tm=v_start;
elseif t>=t_end
    v_tm=v_end;
else
    slope = (v_end-v_start)/(t_end -t_start);
    
    v_tm= slope*(t-t_start) + v_start;
    


end

