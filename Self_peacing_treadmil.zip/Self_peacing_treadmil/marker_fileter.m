function [leftank,leftknee,lefthip,rightank,rightknee,righthip] = marker_fileter(u)

persistent lefthip_save leftank_save righthip_save rightank_save

if isempty(leftank_save)
    lefthip_save = [0 0 0];
    leftank_save = [0 0 0];
    righthip_save = [0 0 0];
    rightank_save = [0 0 0];
end


chan = [0 0 0];
lefthip = [0 0 0];
leftank = [0 0 0];
rightank = [0 0 0];
righthip = [0 0 0];

leftknee = [0 0 0];
rightknee = [0 0 0];

right_collect = zeros(3,3);
left_collect = zeros(3,3);

channel0 = [u(1),u(2),u(3)];
channel1 = [u(4),u(5),u(6)];
channel2 = [u(7),u(8),u(9)];
channel3 = [u(10),u(11),u(12)];
channel4 = [u(13),u(14),u(15)];
channel5 = [u(16),u(17),u(18)];
channel6 = [u(19),u(20),u(21)];
channel7 = [u(22),u(23),u(24)];
channel8 = [u(25),u(26),u(27)];


channel_collect = [channel0;channel1;channel2;channel3;channel4;channel5;channel6;channel7;channel8];


for i = 1:9
    
    if channel_collect(i,3) < 0.06
        
    else
        if channel_collect(i,1) < 0
            left_collect = [left_collect(2:3,:);channel_collect(i,:)];
        elseif channel_collect(i,1) > 0
            right_collect = [right_collect(2:3,:);channel_collect(i,:)];
        else
            disp('Logic not met')
        end
    end
end

for i = 1:3
   if left_collect(i,3) < 0.25
       leftank = left_collect(i,1:3);
   elseif left_collect(i,3) == max(left_collect(:,3))
       lefthip = left_collect(i,1:3);
   else
       leftknee = left_collect(i,1:3);
   end
   
   if right_collect(i,3) < 0.25
       rightank = right_collect(i,1:3);
   elseif right_collect(i,3) == max(right_collect(:,3))
       righthip = right_collect(i,1:3);
   else
       rightknee = right_collect(i,1:3);
   end
end
        

if norm(lefthip -[0 0 0]) < 1e-3
    lefthip = lefthip_save;
else
    lefthip_save = lefthip;
end
% if norm(leftank -[0 0 0]) < 1e-3
%     leftank = leftank_save;
% else
%     leftank_save = leftank;
% end

if norm(righthip -[0 0 0]) < 1e-3
    righthip = righthip_save;
else
    righthip_save = righthip;
end
% if norm(rightank -[0 0 0]) < 1e-3
%     rightank = rightank_save;
% else
%     rightank_save = rightank;
% end



if lefthip(1) == 0 || leftank(1) == 0 || rightank(1) == 0 || righthip(1) == 0 || rightknee(1) == 0 || leftknee(1) == 0
    disp('Zeros Returned')
end
    
end
