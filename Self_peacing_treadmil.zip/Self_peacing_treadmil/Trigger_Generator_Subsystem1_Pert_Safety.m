function [l_strike_curr_scope,r_strike_curr_scope,l_TO_curr_scope,r_TO_curr_scope]  = ...
    fcn(Time,LTrigD, RTrigD,TO_L,TO_R,false_doublesupport)

persistent l_strike_curr
persistent r_strike_curr
persistent l_TO_curr
persistent r_TO_curr
% persistent stateL_prev
% persistent stateR_prev
% persistent tstateL
% persistent tstateR

if isempty(l_strike_curr)
   
    l_strike_curr = -1;
   
    r_strike_curr = -1;
   
    l_TO_curr = -1;
    r_TO_curr = -1;
  
end


%l_strike_predict = r_strike_curr + (l_strike_prev-r_strike_prev);
%r_strike_predict = l_strike_curr + (r_strike_prev - l_strike_prev);

%Treadmill delay + Rise delay
%allow a reasonable amount of time (false_doublesupport) to elapse
%before updating stride parameters
if(LTrigD && (Time > l_strike_curr + false_doublesupport)) %if left trig detects start of HS && .85 sec has elapsed since "current" left heel strike, a new left HS has been detected
    l_strike_curr = Time; %make time of current HS the current time
end
if TO_L
    l_TO_curr = Time;
end

if(RTrigD && (Time > r_strike_curr + false_doublesupport))
    r_strike_curr = Time;
end
if TO_R
    r_TO_curr = Time;
end


l_strike_curr_scope=l_strike_curr;
r_strike_curr_scope=r_strike_curr;
l_TO_curr_scope = l_TO_curr;
r_TO_curr_scope = r_TO_curr;


end